﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public abstract class PassagierBoot : Schip {
        public PassagierBoot(double lengte, double breedte, double tonnage, string naam, int aantalPassagiers)
            : base(lengte, breedte, tonnage, naam) {
            AantalPassagiers = aantalPassagiers;
        }
        public int AantalPassagiers { get; set; }
        public Traject Traject { get; set; }
    }
}
