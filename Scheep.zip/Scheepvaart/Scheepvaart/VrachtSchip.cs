﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
   public abstract class VrachtSchip : Schip {
        public VrachtSchip(double lengte, double breedte, double tonnage, string naam, double cargoWaarde)
            : base(lengte, breedte, tonnage, naam) {
            Cargowaarde = cargoWaarde;
        }
        public double Cargowaarde { get; set; }
        public double Volume { get; set; }
    }
}
