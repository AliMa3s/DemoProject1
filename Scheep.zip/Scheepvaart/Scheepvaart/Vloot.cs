﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public class Vloot {
        private Dictionary<string, Schip> schepen = new Dictionary<string, Schip>();
        public Vloot(String naam)   {
            Naam = naam;
        }
        public string Naam { get; set; }

       

        public void VoegToeSchip(Schip schip) {
            if (!schepen.ContainsKey(schip.Naam)) {
                schepen.Add(schip.Naam,schip);
                schip.Vloot = this;
            }
        }
        public void VerwijderSchip(Schip schip) {
            if (schepen.ContainsKey(schip.Naam)) {
                schepen.Remove(schip.Naam);
                schip.Vloot = null;
            } 
        }
        public Schip ZoekSchip(string naam){
            if (schepen.ContainsKey(naam)) 
                return schepen[naam];
                else
                    return null;
        }
        public double Cargowaarde() {
            double waarde = 0;
            int p = 0;
            foreach (Schip schip in schepen.Values) {
                
                if (schip is PassagierBoot) waarde += ((VrachtSchip)schip).Cargowaarde;
            }
            return waarde;
        }
        public int Passagiers() {
            int p = 0;
            foreach(Schip s in schepen.Values) {
                if (s is PassagierBoot) p += ((PassagierBoot)s).AantalPassagiers;
            }
            return p;
        }
        public double volumeTankers() {
            double v = 0;
            foreach (Schip h in schepen.Values) {
                if (h is VrachtSchip) v += ((VrachtSchip)h).Volume;
            }
            return v;
        }
        public double Tonnage() {
            double t = 0;
            foreach (Schip s in schepen.Values) {
                t += s.Tonnage;
            }
            return t;
        }
        public List<Sleepboot> zoekSleepboten() {
            List<Sleepboot> ls = new List<Sleepboot>();
            foreach (Schip s in schepen.Values) {
                if(s is Sleepboot) ls.Add((Sleepboot)s);
            }
            return ls;
        }
        public void Overzicht() {
            foreach (KeyValuePair<string, Schip> boot in schepen) Console.WriteLine(boot);
        }
    }
}
