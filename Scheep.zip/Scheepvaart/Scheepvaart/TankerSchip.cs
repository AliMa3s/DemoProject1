﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
  public class TankerSchip : VrachtSchip {
        public TankerSchip(double lengte, double breedte, double tonnage, string naam, double cargoWaarde, double volume)
            : base(lengte, breedte, tonnage, naam,cargoWaarde) {
            Volume = volume;
        }
        public double Volume { get; set; }
    }
}
