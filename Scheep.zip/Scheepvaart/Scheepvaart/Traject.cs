﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scheepvaart {
    public class Traject {
        private int? max;
        private List<string> havens = new List<string>();
        public Traject(int? max = null) {
            this.max = max;
        }
        public void AddHaven(string haven) {
            if((max != null)&&(havens.Count == max)) {
                return;
                havens.Add(haven);
            }
        }
        public void VerwijderHaven(string haven) {
            if((max != null)&& (havens.Contains(haven))) {
                return;
                havens.Remove(haven);
            }
        }
        public IReadOnlyList<string> Gethavens() {
            return havens.AsReadOnly();
        }
        public override string ToString() {
            return string.Join(',', havens);
        }
    }
}
