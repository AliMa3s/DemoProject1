﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart.Schepen {
    public class RoRoschip : VrachtSchip {
        public RoRoschip(double lengte, double breedte, double tonnage, string naam, int aantalAutos,int aantalTrucks, double cargowaarde)
: base(lengte, breedte, tonnage, naam, cargowaarde) {
            Aantalautos = aantalAutos;
            AantalTrucks = aantalTrucks;
            
        }
        public List<string> Traject { get; set; }
        public int Aantalautos { get; set; }
        public int AantalTrucks { get; set; }
        public override string ToString() {
            return $"Containerschip: Lengte {Lengte}, Breedte {Breedte}, Tonnage {Tonnage}, naam {Naam}, Aantal Autos {Aantalautos}, " +
                $"Aantal Trucks {AantalTrucks} Traject {Traject}";
        }
    }
}
