﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart.Schepen {
   public class CruiseSchip : PassagierBoot {
        public CruiseSchip(double lengte, double breedte, double tonnage,string naam, int aantalPassagiers )
            : base(lengte, breedte, tonnage, naam, aantalPassagiers) {
            Traject = traject;
        }
        public List<string> Traject { get; set; }
        public List<string> traject { get; }

        public override string ToString() {
            return $"CruiseSchip: Lengte {Lengte}, Breedte {Breedte}, Tonnage {Tonnage}, naam {Naam}, Aantal Passagiers {AantalPassagiers} Traject {Traject}";
        }
    }
}
