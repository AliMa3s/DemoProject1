﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart.Schepen {
    public class ContainerSchip : VrachtSchip{
        public ContainerSchip(double lengte, double breedte, double tonnage, string naam, int aantalContainers, double cargowaarde)
  : base(lengte, breedte, tonnage, naam,cargowaarde) {
            
            AantalContainers = aantalContainers;
        }
        public List<string> Traject { get; set; }
        public int AantalContainers { get; set; }
        public override string ToString() {
            return $"Containerschip: Lengte {Lengte}, Breedte {Breedte}, Tonnage {Tonnage}, naam {Naam}, Aantal Containers {AantalContainers} Traject {Traject}";
        }
    }
}
