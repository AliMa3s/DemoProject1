﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart.Schepen {
   public class Veerboot : PassagierBoot {
        public Veerboot(double lengte, double breedte, double tonnage, string naam, int aantalPassagiers, List<string> traject)
    : base(lengte, breedte, tonnage, naam, aantalPassagiers) {
            Traject = traject;
        }
        public List<string> Traject { get; set; }
        public override string ToString() {
            return $"Veerboot: Lengte {Lengte}, Breedte {Breedte}, Tonnage {Tonnage}, naam {Naam}, Aantal Passagiers {AantalPassagiers} Traject {Traject}";
        }
    }
}
