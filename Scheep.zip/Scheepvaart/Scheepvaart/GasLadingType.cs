﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public enum  GasLadingType {
        LPG,LNG,Amoniack
    }
}
