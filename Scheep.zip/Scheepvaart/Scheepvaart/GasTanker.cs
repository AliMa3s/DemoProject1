﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public class GasTanker : TankerSchip{
        public GasTanker(double lengte, double breedte, double tonnage, string naam, double cargowaarde, double volume, GasLadingType lading)
            : base(lengte, breedte, tonnage, naam, cargowaarde, volume) {
            Lading = lading;
        }
        public GasLadingType Lading { get; set; }
        public override string ToString() {
            return $"Gastanker: Lengte {Lengte}, Breedte {Breedte}, Tonnage {Tonnage}, naam {Naam}, Aantal volume {Volume} Lading {Lading}";
        }
    }
    
}
