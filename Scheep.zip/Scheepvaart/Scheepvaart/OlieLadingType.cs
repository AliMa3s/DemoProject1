﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public enum OlieLadingType {
        Olie,benzeen,diesel,nafta
    }
}
