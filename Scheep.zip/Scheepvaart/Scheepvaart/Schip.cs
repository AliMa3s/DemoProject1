﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public abstract class Schip {
    
        public Schip(double lengte, double breedte, double tonnage, string naam) {
            Lengte = lengte;
            Breedte = breedte;
            Tonnage = tonnage;
            Naam = naam;
        }
        public double Lengte { get; set; }
        public double Breedte { get; set; }
        public double Tonnage { get; set; }
        public string Naam { get; set; }
        public Vloot Vloot { get;  set; }
        public override string ToString() {
            return $"Schip {Naam}, {Lengte}, {Breedte}, {Tonnage},{Vloot.Naam},{this.GetType()}";
        }
    }
}
