﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    class OlieTanker : TankerSchip {
        public OlieTanker(double lengte, double breedte, double tonnage, string naam, double cargowaarde, double volume, OlieLadingType lading)
           : base(lengte, breedte, tonnage, naam, cargowaarde, volume) {
            Lading = lading;
        }
        public OlieLadingType Lading { get; set; }
        public override string ToString() {
            return $"Olietanker: Lengte {Lengte}, Breedte {Breedte}, Tonnage {Tonnage}, naam {Naam}, Aantal volume {Volume} Lading {Lading}";
        }
    }
}
