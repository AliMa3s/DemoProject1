﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
    public class Rederij {
        private Dictionary<string, Vloot> Vloten = new Dictionary<string, Vloot>();
        public Rederij(string naam) {
            Naam = naam;
        }
        public string Naam {get;set;}

        public SortedDictionary<int,List<Vloot>> tonnagePerVloot() {
            SortedDictionary<int, List<Vloot>> tpv = new SortedDictionary<int, List<Vloot>>();
            foreach (Vloot v in Vloten.Values) {
                int t = (int)v.Tonnage();
                if (tpv.ContainsKey(t)) tpv[t].Add(v);
                else { tpv.Add(t, new List<Vloot>() { v }); }
            }
            return tpv;
        }
        public Schip zoekSchip(string schipnaam) {
            foreach (Vloot v in Vloten.Values) {
                {
                    Schip s;
                    if((s = v.ZoekSchip(schipnaam)) != null) {
                        return s;
                    }
                    
                }
                
            }
            return null;
        }
        public int passagiers() {
            int p = 0;
            foreach (Vloot v in Vloten.Values) {
                p += v.Passagiers();
            }
            return p;
        }
        public void plaatsSchipInAndereVloot(string schipnaam, string vlootnaam) {
            Schip s = zoekSchip(schipnaam);
            if (s !=  null)
        {
                Vloten[s.Vloot.Naam].VerwijderSchip(s);
                Vloten[vlootnaam].VoegToeSchip(s);
                s.Vloot = Vloten[vlootnaam];
            }
        }

        //public double TotaleCargoWaarde() {
        //    double result = 0;
        //    foreach(Vloot v in Vloten) {
        //        foreach(Schip s in v.Schepen) {
        //            if(s.GetType() == typeof(VrachtSchip)) {
        //                result += ((VrachtSchip)s).Cargowaarde;
        //            }
        //        }
        //    }
        //    return result;
        //}
    }
}
