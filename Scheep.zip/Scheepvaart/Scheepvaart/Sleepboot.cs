﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scheepvaart {
   public class Sleepboot : Schip{
        public Sleepboot(double lengte, double breedte, double tonnage, string naam )
         : base(lengte, breedte, tonnage, naam) {

        }
    }
}
