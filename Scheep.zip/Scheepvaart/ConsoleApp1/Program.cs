﻿using System;
using Scheepvaart;
using Scheepvaart.Schepen;


namespace ConsoleApp1 {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Hello World!");
            Schip a = new ContainerSchip(120, 25, 800, "Container C1", 66, 86000);
            Schip b = new CruiseSchip(250, 45, 900, "CruiseSchip p01", 900);

            RoRoschip c = new RoRoschip(290, 35,700, "RORO R001", 45, 20, 98000);
            VrachtSchip d = new ContainerSchip(100, 21, 800, "Vracht V09",55, 9800);

            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);
        }
    }
}
